const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

// Safaricom Daraja Credentials from Environment Variables
const CONSUMER_KEY = process.env.CONSUMER_KEY || "YOUR_CONSUMER_KEY";
const CONSUMER_SECRET = process.env.CONSUMER_SECRET || "YOUR_CONSUMER_SECRET";
const BUSINESS_SHORT_CODE = process.env.BUSINESS_SHORT_CODE || "174379"; // Safaricom Sandbox Shortcode
const PASSKEY = process.env.PASSKEY || "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";

// OAuth Token Generator
async function getAccessToken() {
    const auth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString('base64');
    const response = await axios.get(
        'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials',
        { headers: { Authorization: `Basic ${auth}` } }
    );
    return response.data.access_token;
}

// Job Listings Endpoint
app.get('/api/jobs', (req, res) => {
    const jobs = [
        { id: 1, title: "Secondary Teacher II (Mathematics/Physics)", salary: "Ksh 35,000 - 45,000", county: "Nairobi", tscGrade: "C2" },
        { id: 2, title: "Primary School Teacher I (CBC)", salary: "Ksh 27,000 - 33,000", county: "Kiambu", tscGrade: "C1" },
        { id: 3, title: "Senior Teacher II (English/Literature)", salary: "Ksh 43,000 - 55,000", county: "Nakuru", tscGrade: "C3" }
    ];
    res.json(jobs);
});

// STK Push Payment Endpoint
app.post('/api/stkpush', async (req, res) => {
    const { phone, amount } = req.body;

    try {
        const token = await getAccessToken();
        const date = new Date();
        const timestamp = date.getFullYear() +
            ("0" + (date.getMonth() + 1)).slice(-2) +
            ("0" + date.getDate()).slice(-2) +
            ("0" + date.getHours()).slice(-2) +
            ("0" + date.getMinutes()).slice(-2) +
            ("0" + date.getSeconds()).slice(-2);

        const password = Buffer.from(BUSINESS_SHORT_CODE + PASSKEY + timestamp).toString('base64');

        const stkData = {
            BusinessShortCode: BUSINESS_SHORT_CODE,
            Password: password,
            Timestamp: timestamp,
            TransactionType: "CustomerPayBillOnline",
            Amount: amount || 1000,
            PartyA: phone,
            PartyB: BUSINESS_SHORT_CODE,
            PhoneNumber: phone,
            CallBackURL: process.env.CALLBACK_URL || "https://your-render-app.onrender.com/api/callback",
            AccountReference: "TSC_Job_App",
            TransactionDesc: "Application Fee"
        };

        const response = await axios.post(
            'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest',
            stkData,
            { headers: { Authorization: `Bearer ${token}` } }
        );

        res.status(200).json({ status: "Success", data: response.data });
    } catch (error) {
        res.status(500).json({ status: "Error", message: error.response ? error.response.data : error.message });
    }
});

// Callback Endpoint
app.post('/api/callback', (req, res) => {
    console.log("M-Pesa Callback Data:", JSON.stringify(req.body));
    res.status(200).send("OK");
});

// Health check root route
app.get('/', (req, res) => {
    res.send("TSC Kenya Backend Server is Running!");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
