package com.example.tscjobs

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class PaymentRequest(val phone: String, val amount: Int)
data class PaymentResponse(val status: String, val message: String?)

interface ApiService {
    @POST("api/stkpush")
    fun triggerStkPush(@Body request: PaymentRequest): Call<PaymentResponse>
}

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etPhone = findViewById<EditText>(R.id.etPhone)
        val btnPayAndApply = findViewById<Button>(R.id.btnPayAndApply)

        // Replace with your deployed Render URL or local server IP
        val retrofit = Retrofit.Builder()
            .baseUrl("https://your-render-backend.onrender.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)

        btnPayAndApply.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            if (phone.isEmpty() || phone.length < 10) {
                Toast.makeText(this, "Please enter a valid phone number (e.g. 254741601604)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val request = PaymentRequest(phone = phone, amount = 1000)

            apiService.triggerStkPush(request).enqueue(object : Callback<PaymentResponse> {
                override fun onResponse(call: Call<PaymentResponse>, response: Response<PaymentResponse>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MainActivity, "STK Push Sent! Check phone for M-Pesa PIN prompt.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Server Error: Payment request failed.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<PaymentResponse>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Connection Error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}
