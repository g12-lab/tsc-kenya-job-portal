# TSC Kenya Employment Portal with M-Pesa STK Push

Full end-to-end mobile job application system for TSC Kenya teaching vacancies with integrated Safaricom M-Pesa Daraja 2.0 payments.

## Project Structure
- `/backend`: Node.js + Express API handling Safaricom Daraja OAuth and STK Push requests.
- `/android`: Native Kotlin Android App configured with Retrofit API client.

## Quick Setup Guide for Mobile/GitHub

### 1. Uploading to GitHub directly from Android:
1. Extract `tsc-kenya-job-portal.zip`.
2. Go to [GitHub.com](https://github.com) on your mobile browser.
3. Tap **New Repository**, name it `tsc-kenya-job-portal`.
4. Tap **Upload files** and drag/select the files from this unzipped folder into GitHub.

### 2. Deploying Backend on Render (Free Hosting):
1. Sign up at [Render.com](https://render.com).
2. Click **New +** -> **Web Service**.
3. Select your GitHub repository (`tsc-kenya-job-portal`).
4. Set Root Directory to `backend`.
5. Set Build Command to `npm install` and Start Command to `node server.js`.
6. Add Environment Variables:
   - `CONSUMER_KEY`: Safaricom Developer Key
   - `CONSUMER_SECRET`: Safaricom Developer Secret
7. Click **Deploy**.

### 3. M-Pesa Application Flow:
- User selects a TSC post and enters their phone number (e.g. `254741601604`).
- Tapping **Pay Ksh 1,000 & Apply** sends an API call to the Node.js backend.
- Node.js requests an OAuth token from Safaricom Daraja and fires an STK Push to the user's phone.
